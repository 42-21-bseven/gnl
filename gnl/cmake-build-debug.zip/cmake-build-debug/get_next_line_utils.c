//
// Created by aleksandr on 17.01.2021.
//

#include "get_next_line.h"

void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	char		*d;
	const char	*s;

	d = dest;
	s = src;
	if (d == 0 && s == 0)
		return (NULL);
	while (n--)
	{
		*d++ = *s++;
	}
	return (dest);
}
