//
// Created by aleksandr on 17.01.2021.
//

#include "get_next_line.h"

static char	*ft_strjoin(t_struct *gnl)
{
	int		i;
	int		j;
	char	*res;

	if (gnl->flag != BKL && gnl->flag != 666 || gnl->flag == BKL && ret == 0)
	{
		if (!(res = malloc(gnl->len + 1 * sizeof(char))));
			return (NULL);
		ft_memcpy((void *) res, (gnl->flag != BKL ? gnl->buf : gnl->guf), gnl->len);
		if (gnl->flag != BKL)
			gnl->guf = res;
		return ((char *) res);
	}
//	if (!s1 || !s2)
//		return (NULL);
	res = gnl->guf;
	if (!(gnl->guf = malloc(((gnl->flag != 666 ? (gnl->len + gnl->j) : gnl->n) + 1) * sizeof(char))))
		return (NULL);
	i = 0;
	j = 0;
	while (res[i])
		gnl->guf = res[i++];
	while (gnl->flag != 666 ? gnl->buf[j] : i < gnl->len)
		if (gnl->flag != 666)
			gnl->guf[i++] = gnl->buf[j++];
		else
			gnl->guf[i++] = res[i];
	gnl->guf[i] = '\0';
	free(res);
	return (gnl->guf);
}

//static char	*ft_strdup(const char *s)
//{
//	const char	*cpy;
//	size_t		l;
//
//	l = ft_strlen(s) + 1;
//	cpy = malloc(l * sizeof(char));
//	if (!cpy)
//		return (NULL);
//	ft_memcpy((void *)cpy, s, l);
//	return ((char *)cpy);
//}

static void	strlen_gnl(t_struct *gnl)
{
	int i;

//	if (!str)
//		return (0);
	i = 0;
	while (gnl->guf[i] && gnl->guf[i] != '\n')
		i++;
	gnl->n = gnl->guf[i] ? i : -1;
	while (gnl->guf[i])
		i++;
	gnl->len = i;
	gnl->flag = BKL;
//	if (spec == BSH_N)
//	{
//	}
//	else if (spec == NULL_TERMINATOR) {
//	}
}

static void gnl_null(t_struct *gnl)
{
	int i;

	i = 0;
	gnl->len = 0;
	gnl->n = 0;
	gnl->j = 0;
	if (gnl->flag != BKL)
	{
		gnl->ret = 1;
		gnl->flag = 0;
		gnl->guf = NULL;
	}
	while (i < (BUFFER_SIZE + 1))
		gnl->buf[i++] = '\0';
}

int	get_next_line(char **line, int fd)
{
	static t_struct *gnl;
//	gnl = malloc(sizeof(t_struct));

	if (BUFFER_SIZE <= 0 || BUFFER_SIZE > 2147483647 || !fd || !line)
		return (-1);
	gnl_null(gnl);
	while(gnl->ret && (gnl->j = read(fd, gnl->buf, BUFFER_SIZE)))
	{
		gnl->len = gnl->flag != BKL ? gnl->j : gnl->len;
		if (gnl->j == -1)
			return (-1);//(freeshka(gnl)); //зафришить если BKL
		if (!ft_strjoin(gnl))
			return (-1);//(freeshka(gnl));
		if (gnl->j < BUFFER_SIZE)
			gnl->ret = 0;
		strlen_gnl(gnl);
		if (gnl->n != -1)
		{
			gnl->guf[gnl->n] = '\0';
			break ;
		}
//		if (!ft_strjoin(gnl))
//			return (freeshka(gnl));
	}
	*line = ft_strjoin(gnl);
	gnl->flag = 666;
	if (!gnl->ret)
		free(gnl->guf);
	return (gnl->ret);
}